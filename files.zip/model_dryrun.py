"""
OTP MODEL DRY-RUN  (synthetic delays)
=====================================
Proves the full train_otp_model pipeline works end-to-end. Generates realistic
synthetic delays keyed to features we KNOW drive lateness (peak hours, position
in trip, upstream delay), trains the real LightGBM model, and reports accuracy +
feature importance.

*** This is a DRY RUN. The labels are synthetic. ***
When you have 2+ weeks of logged realtime data, the ONLY change is to load the
real features parquet instead of make_synthetic(). The model code is identical.
"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
OUT = Path(__file__).parent / "map_data"
OUT.mkdir(exist_ok=True)


def make_synthetic(n=40000):
    """Synthetic (trip, stop) observations whose delay depends on real-world drivers."""
    hour = rng.integers(5, 24, n)
    minute = rng.integers(0, 60, n)
    weekday = rng.integers(0, 5, n)
    stop_seq = rng.integers(1, 45, n)
    frac_of_trip = stop_seq / 45.0
    route_family = rng.choice([900, 901, 915, 916, 302, 403, 405, 921], n)
    is_peak_am = ((hour >= 7) & (hour <= 9)).astype(int)
    is_peak_pm = ((hour >= 16) & (hour <= 18)).astype(int)
    # upstream delay accumulates along the trip (autocorrelated)
    upstream = rng.normal(0, 60, n) + frac_of_trip * rng.normal(40, 30, n)

    # TRUE delay model (this is what the ML must learn):
    delay = (
        20                                    # base
        + is_peak_am * 95                     # AM peak adds delay
        + is_peak_pm * 130                    # PM peak worse
        + frac_of_trip * 70                   # delay grows along trip
        + 0.55 * upstream                     # upstream delay propagates (dominant)
        + (route_family == 901) * 60          # 901 is structurally slow
        + (route_family == 900) * 40
        + rng.normal(0, 45, n)                # noise
    )
    on_time = ((delay >= -60) & (delay <= 300)).astype(int)
    return pd.DataFrame(dict(
        hour=hour, minute=minute, weekday=weekday, stop_seq=stop_seq,
        frac_of_trip=frac_of_trip, route_family=route_family,
        is_peak_am=is_peak_am, is_peak_pm=is_peak_pm,
        upstream_delay_sec=upstream, on_time=on_time))


def train(df):
    try:
        import lightgbm as lgb
    except ImportError:
        import subprocess, sys
        subprocess.run([sys.executable, "-m", "pip", "install", "lightgbm",
                        "--break-system-packages", "-q"], check=True)
        import lightgbm as lgb
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score, accuracy_score

    feats = ["hour","minute","weekday","stop_seq","frac_of_trip","route_family",
             "is_peak_am","is_peak_pm","upstream_delay_sec"]
    X, y = df[feats], df["on_time"]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.25, random_state=0)
    model = lgb.LGBMClassifier(n_estimators=300, learning_rate=.05, num_leaves=31,
                               subsample=.8, verbose=-1)
    model.fit(Xtr, ytr, categorical_feature=["route_family"])
    proba = model.predict_proba(Xte)[:, 1]
    auc = roc_auc_score(yte, proba)
    acc = accuracy_score(yte, (proba > .5).astype(int))
    imp = pd.Series(model.feature_importances_, index=feats).sort_values(ascending=False)
    return model, auc, acc, imp, feats


def main():
    print("Generating synthetic delay data (40k observations)...")
    df = make_synthetic()
    print(f"  On-time rate: {df['on_time'].mean()*100:.1f}%")
    print("Training LightGBM OTP model...")
    model, auc, acc, imp, feats = train(df)
    print(f"  Test AUC:      {auc:.3f}")
    print(f"  Test accuracy: {acc*100:.1f}%")
    print("  Feature importance (gain):")
    for f, v in imp.items():
        print(f"    {f:<22} {int(v)}")

    # save importance for the presentation chart
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 4.2))
    impn = imp / imp.sum()
    colors = ["#22d3b8" if f == "upstream_delay_sec" else "#5b8bd6" for f in impn.index]
    ax.barh(impn.index[::-1], impn.values[::-1], color=colors[::-1], edgecolor="none")
    ax.set_title("OTP model — feature importance  (DRY RUN, synthetic delays)",
                 fontsize=11, weight="bold")
    ax.set_xlabel("relative importance")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT / "model_feature_importance.png", dpi=130, facecolor="white")
    print(f"\nSaved {OUT/'model_feature_importance.png'}")
    print(f"\n*** DRY RUN COMPLETE. AUC {auc:.2f} confirms the pipeline learns the signal.")
    print("    Swap make_synthetic() for your logged features parquet to train for real.")


if __name__ == "__main__":
    main()
