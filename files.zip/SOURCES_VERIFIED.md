# DRT Project — Verified Sources & Authentication

Every load-bearing claim in this project, with its verification status as of **2026-05-22**.
Use this as the appendix slide so every number in your presentation is traceable.

---

## A. Claims VERIFIED by direct test

| # | Claim | How verified | Status |
|---|-------|--------------|--------|
| 1 | Realtime VehiclePositions feed is live | Fetched `drtonline.durhamregiontransit.com/gtfsrealtime/VehiclePositions` → returns `application/x-google-protobuf` | ✅ CONFIRMED |
| 2 | Realtime TripUpdates feed is live | Fetched `.../gtfsrealtime/TripUpdates` → returns protobuf | ✅ CONFIRMED |
| 3 | GTFS static feed | Downloaded & parsed `maps.durham.ca/OpenDataGTFS/GTFS_Durham_TXT.zip` | ✅ CONFIRMED |

## B. Claims VERIFIED against DRT primary sources

| # | Claim | Source | Status |
|---|-------|--------|--------|
| 4 | On Demand running at 240% over capacity | DRT December 2024 TEC highlights (durhamregiontransit.com news) | ✅ CONFIRMED |
| 5 | Ridership/rev-hr 32% below peer comparators | DRT TEC report DocumentId 8701 (escribemeetings) | ✅ CONFIRMED |
| 6 | Ridership per capita 69% below peer comparators | DRT TEC report DocumentId 8701 | ✅ CONFIRMED |
| 7 | PULSE roster = 900, 901, 915, 916 (+902 added 2024) | CPTDB Wiki + DRT "Route Ahead" 2022–25 plan | ✅ CONFIRMED |
| 8 | Three PULSE routes = ~40% of boardings | DRT Dec 2023 news release | ✅ CONFIRMED |
| 9 | 2024 record ridership ~13 million | DRT Nov 2024 TEC (13.0M projection) + TEC Chair year-end statement ("over 13 million") | ✅ CONFIRMED |
| 10 | Realtime feed indexed by Transitland | Onestop ID `f-dpz-durhamregiontransit~rt` | ✅ CONFIRMED |

## C. Claims computed from the real GTFS feed (reproducible)

| # | Claim | Computed value | Status |
|---|-------|----------------|--------|
| 11 | Weekday routes in service | 36 (of 39 total) | ✅ from feed |
| 12 | System median commercial speed | 29.0 km/h | ✅ from feed |
| 13 | Route 901 is slowest PULSE | 22.6 km/h | ✅ from feed |
| 14 | Bucket split A/B/C/D | 4 / 22 / 4 / 6 | ✅ from feed |
| 15 | Schedule index size | 8,939,738 scheduled stop-arrivals | ✅ from feed |
| 16 | Coverage-gap cells (400m–1.5km from any stop) | 1,464 | ✅ from feed |
| 17 | Dense On Demand clusters (≥8 stops/cell) | 99 | ✅ from boarding-points file |

## D. Claims that NEED CORRECTION (do not present as-is)

| # | Claim from earlier research draft | Problem | Correct version |
|---|-----------------------------------|---------|-----------------|
| 18 | "2024 on-time performance = 69%" | Could not find a primary source. Suspiciously identical to the *ridership-per-capita-below-peer* 69%. Likely a conflation. | **Do not cite an OTP %.** Say "OTP to be measured from realtime feed." |
| 19 | "Revenue hours per capita = 0.76" | Stale | Current figure is **0.9** (DRT 2025 supplementary report); 10-yr target 1.4 |
| 20 | `TRNST_Routes.csv` PULSE roster | Only tags 900/901 as PULSE; lists "980 Late Night" not in current service | File is **stale**; use GTFS + sources 7 for the live roster |
| 21 | Detailed productivity table (40/25/20/8 boardings/rev-hr) | Plausible, consistent with DRT Service Guidelines, but not re-verified line-by-line in this pass | Cite as "per DRT Service Guidelines" and verify the exact table before presenting figures |

## E. Things that DO NOT exist yet (be honest in the presentation)

- **On-time performance numbers** — require running the logger 2+ weeks.
- **Boardings per route/hour** — not in any public dataset; must request from DRT.
- **A trained model on real data** — the model code is proven (AUC 0.91 on synthetic dry-run) but has no real labels yet.

---

## How to present this honestly

When a number is on a slide, tag it with one of:
- **[MEASURED]** — computed from the GTFS feed (sources 11–17)
- **[DRT]** — DRT's own published figure (sources 4–10)
- **[VERIFIED LIVE]** — tested directly (sources 1–3)
- **[PENDING DATA]** — awaiting realtime collection (section E)

This makes your presentation bulletproof: every claim is either traceable to a source,
reproducible from the feed, or openly flagged as not-yet-available.
